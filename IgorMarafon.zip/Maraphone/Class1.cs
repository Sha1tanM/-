﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Maraphone
{
    public static class Util
    {
        public static MarafonEntities database;
        public static MarafonEntities db
        {
            get
            {
                if(database == null)
                {
                    database = new MarafonEntities();

                }
                return database;
            }
        }
    }
}
